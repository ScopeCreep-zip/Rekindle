DigitalGrenade.com Skin for XFire v1
by Suchey
Suchey@digitalgrenade.com


----------------------------
INSTALLATION
----------------------------	

Place the "diggren" folder contained within this zip file to your XFire skin directory.
The default location of the XFire skin directory is: C:\Program Files\Xfire\skins

open XFire...select the TOOLS tab which is on the top menu...then select "skin" and choose diggren.

Enjoy!




