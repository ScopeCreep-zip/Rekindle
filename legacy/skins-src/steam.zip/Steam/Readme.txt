   ..::EvilpiMpErs Steam Skin::..

Evilpimpa24@xfire
-------------------------------------------
1.This skin was made by me and me only.
2.I Could not contact steam for permissions, And
if they want me to get rid of the skin let them 
e-mail me at evilpimper24@hotmail.com .
3.Thanks go out to Gunowar for hosting my skin.
4.report any bugs to me on xfire.
5.Tell me what u think of the skin.
6.tell me your ideas for skins and if you can
post a layout of it(what it will look liek 
if completed.