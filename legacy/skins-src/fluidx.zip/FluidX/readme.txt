+-------------------------------------------+
|Project: FluidX Xfire Skin                 |
|                                           |
|Author:  Max Carey <msc@morgancarey.co.uk> |
|                                           |
|Date:    08/10/04                          |
+-------------------------------------------+

Thanks for downloading my FluidX Xfire skin.
FluidX was created for the official Xfire
skin contest.

To use, extract the contents of this zip to
your Xfire/skins directory.

Enjoy.  